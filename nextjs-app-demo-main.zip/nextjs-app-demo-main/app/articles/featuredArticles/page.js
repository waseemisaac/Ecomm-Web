const FeaturedArticlesPage = () => {
	return (
		<div>
			<h1>Featured Articles</h1>
		</div>
	);
};

export default FeaturedArticlesPage;
