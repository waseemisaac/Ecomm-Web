export default function LoadingPostDetails() {
	return (
		<div>
			<h1>Loading 👌🏻</h1>
		</div>
	);
}
